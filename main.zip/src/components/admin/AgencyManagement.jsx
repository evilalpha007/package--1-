import React from "react";

const AgencyManagement = () => {
  return <div>AgencyManagement</div>;
};

export default AgencyManagement;

import React from "react";

export default function InPlayScreen() {
  return <div></div>;
}

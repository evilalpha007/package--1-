import React from "react";

export default function SlotsScreen() {
  return <div></div>;
}

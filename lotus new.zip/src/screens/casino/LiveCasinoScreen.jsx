import React from "react";

export default function LiveCasinoScreen() {
  return <div></div>;
}

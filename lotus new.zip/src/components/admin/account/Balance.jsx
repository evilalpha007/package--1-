import React from "react";

const Balance = () => {
  return <div>
  <div className="balance">
  <h2>Balance Information</h2>
  <hr />
  <div className="balancec_details">
  
  <div className=" mt-3  ">
  <div className="balance_button d-flex p-1 justify-content-around">
  <span>Net Exposure</span>
  <span className="green">00</span>
  </div>
  <div className="balance_button mt-3 d-flex p-1 justify-content-around">
  <span>Net Exposure</span>
  <span className="green">00</span>
  </div>
  <div className="balance_button mt-3 d-flex p-1 justify-content-around">
  <span>Net Exposure</span>
  <span className="green">00</span>
  </div>
  <div className="balance_button mt-3 d-flex p-1 justify-content-around">
  <span>Net Exposure</span>
  <span className="green">00</span>
  </div>
  <div className="balance_button mt-3 d-flex p-1 justify-content-around">
  <span>Net Exposure</span>
  <span className="green">00</span>
  </div>
  </div>
  </div>
  </div>
  </div>;
};

export default Balance;

import React from "react";

export default function AdminRoutes() {
  return <div>AdminRoutes</div>;
}

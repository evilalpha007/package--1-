import React from 'react'

const Footer = () => {
  return (
    <div className="footer">
    <p>Rules & Regulations
    © 2016-2022
    | </p>
<img src="./android.png" className="footer_img" alt="" />
    </div>
  )
}

export default Footer
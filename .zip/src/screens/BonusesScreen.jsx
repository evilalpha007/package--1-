import React from "react";

export default function BonusesScreen() {
  return <div></div>;
}

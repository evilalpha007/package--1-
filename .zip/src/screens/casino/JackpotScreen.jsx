import React from "react";

export default function JackpotScreen() {
  return <div></div>;
}

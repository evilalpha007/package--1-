import React from "react";

export default function CasinoScreen() {
  return <div></div>;
}

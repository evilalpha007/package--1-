import React from "react";

export default function SportsBookScreen() {
  return <div></div>;
}

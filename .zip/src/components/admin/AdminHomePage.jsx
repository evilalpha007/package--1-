import React from "react";

const AdminHomePage = () => {
  return <div className="">Home Component</div>;
};

export default AdminHomePage;

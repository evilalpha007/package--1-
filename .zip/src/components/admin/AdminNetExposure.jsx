import React from "react";

export default function AdminNetExposure() {
  return <div>AdminNetExposure</div>;
}

import React from "react";

export default function AdminBlockMarket() {
  return <div>AdminBlockMarket</div>;
}

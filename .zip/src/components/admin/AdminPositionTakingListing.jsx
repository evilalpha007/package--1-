import React from "react";

export default function AdminPositionTakingListing() {
  return <div>PositionTakingListing</div>;
}

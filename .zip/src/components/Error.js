import React from "react";

const Error = () => {
  return <div>Data not found</div>;
};

export default Error;

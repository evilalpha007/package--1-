import React from "react";

export default function PrivateRoutes() {
  return <div>PrivateRoutes</div>;
}
